# blackjack
A simple Blackjack game in Javascript, HTML and CSS.
